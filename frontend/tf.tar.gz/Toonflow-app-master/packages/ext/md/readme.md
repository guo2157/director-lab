# Markdown 文档扩展

支持 `.md`、`.markdown` 文件，扩展标识为 `ext-md`。

本包私有实现 Tiptap 3.31.3 编辑器，默认富文本，可切换原文。工具栏、查找、图片粘贴与拖入、相对图片和链接均由本包维护。Tiptap、marked、DOMPurify 通过脚手架 external 复用宿主依赖，不重复打包，也不共享编辑器组件。

正文绑定 `context.text`，编辑时同步调用 `context.updateText`。自动保存、版本冲突、错误重试与标签关闭仍由文档宿主管理；本包不保留独立草稿或延迟提交。文件操作、链接打开、剪贴板、搜索定位及视图可见状态均使用宿主传入的能力。

构建产物包含扩展元数据、私有编辑器与样式；宿主在执行扩展前按需加载共享依赖。旧文档的下划线、高亮、上下标、段落对齐及复杂表格仍以混合 HTML 保存；仅打开文件或切换模式不会自动改写原文。

在仓库根目录安装依赖后，可在 `packages/ext/md` 目录运行 `bun run typecheck`；使用生产环境执行 `bun run build`，产物位于仓库根目录的 `build/ext/ext-md.umd.js`。开发构建或 watch 会同步产物到 `data/ext`。
