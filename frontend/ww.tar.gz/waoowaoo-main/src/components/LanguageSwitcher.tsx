'use client'

import { useEffect, useRef, useState } from 'react'
import { useLocale, useTranslations } from 'next-intl'
import { type Locale } from '@/i18n/routing'
import ConfirmDialog from './ConfirmDialog'
import { AppIcon } from '@/components/ui/icons'
import { usePathname, useRouter } from '@/i18n/navigation'

const LANGUAGE_LABELS: Record<Locale, string> = {
    zh: '简体中文',
    en: 'English',
}

const SWITCH_CONFIRM_COPY: Record<Locale, { title: string; message: string; action: string; cancel: string; triggerLabel: string }> = {
    zh: {
        title: '切换语言？',
        message:
            '切换到 {targetLanguage} 后，不仅界面文字会改变，整条流程的提示词模板、剧本生成和任务输出语言也会同步切换。是否继续？',
        action: '确认切换',
        cancel: '取消',
        triggerLabel: '切换语言',
    },
    en: {
        title: 'Switch language?',
        message:
            'Switching to {targetLanguage} will update not only interface text, but also end-to-end prompt templates, script generation, and workflow output language. Continue?',
        action: 'Switch now',
        cancel: 'Cancel',
        triggerLabel: 'Switch language',
    },
}

function isSupportedLocale(locale?: string): locale is Locale {
    return locale === 'zh' || locale === 'en'
}

interface LanguageSwitcherProps {
    /**
     * pill: standalone rounded trigger with its own dropdown (default, public pages).
     * menu-row: full-width row for embedding inside the account settings menu;
     * options expand inline within the host card instead of a floating dropdown.
     */
    variant?: 'pill' | 'menu-row'
}

export default function LanguageSwitcher({ variant = 'pill' }: LanguageSwitcherProps) {
    const router = useRouter()
    const pathname = usePathname()
    const locale = useLocale()
    const tNav = useTranslations('nav')
    const containerRef = useRef<HTMLDivElement | null>(null)
    const [isMenuOpen, setIsMenuOpen] = useState(false)
    const [showConfirm, setShowConfirm] = useState(false)
    const [pendingLocale, setPendingLocale] = useState<Locale | null>(null)

    if (!isSupportedLocale(locale)) {
        throw new Error('LanguageSwitcher requires locale to be zh or en')
    }
    const currentLocale: Locale = locale
    const targetLocale: Locale = currentLocale === 'zh' ? 'en' : 'zh'
    const activeLocaleForCopy: Locale = pendingLocale ?? targetLocale
    const confirmCopy = SWITCH_CONFIRM_COPY[activeLocaleForCopy]

    useEffect(() => {
        if (!isMenuOpen) return

        const handleClickOutside = (event: MouseEvent) => {
            if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
                setIsMenuOpen(false)
            }
        }

        document.addEventListener('mousedown', handleClickOutside)
        return () => {
            document.removeEventListener('mousedown', handleClickOutside)
        }
    }, [isMenuOpen])

    const requestLanguageSwitch = (newLocale: Locale) => {
        setIsMenuOpen(false)
        if (newLocale === currentLocale) return
        setPendingLocale(newLocale)
        setShowConfirm(true)
    }

    const confirmLanguageSwitch = () => {
        if (!pendingLocale) {
            throw new Error('LanguageSwitcher confirm requires a pending locale')
        }
        setShowConfirm(false)
        setPendingLocale(null)
        router.replace(pathname, { locale: pendingLocale })
    }

    const cancelLanguageSwitch = () => {
        setShowConfirm(false)
        setPendingLocale(null)
    }

    const confirmDialog = (
        <ConfirmDialog
            show={showConfirm}
            title={confirmCopy.title}
            message={confirmCopy.message.replace('{targetLanguage}', pendingLocale ? LANGUAGE_LABELS[pendingLocale] : '')}
            confirmText={confirmCopy.action}
            cancelText={confirmCopy.cancel}
            onConfirm={confirmLanguageSwitch}
            onCancel={cancelLanguageSwitch}
            type="info"
        />
    )

    if (variant === 'menu-row') {
        return (
            <>
                <div>
                    <button
                        type="button"
                        onClick={() => setIsMenuOpen((prev) => !prev)}
                        aria-label={SWITCH_CONFIRM_COPY[currentLocale].triggerLabel}
                        aria-expanded={isMenuOpen}
                        className="glass-menu-item"
                    >
                        <AppIcon name="globe" className="h-4 w-4 shrink-0" />
                        <span className="flex-1 text-left">{tNav('settingsMenu.language')}</span>
                        <span className="text-xs text-[var(--glass-text-tertiary)]">{LANGUAGE_LABELS[currentLocale]}</span>
                        <AppIcon
                            name="chevronDown"
                            className={`h-3.5 w-3.5 shrink-0 text-[var(--glass-text-tertiary)] transition-transform duration-150 ${isMenuOpen ? 'rotate-180' : ''}`}
                        />
                    </button>
                    {isMenuOpen ? (
                        <div className="mt-1 space-y-0.5 rounded-[10px] bg-[var(--glass-selection-bg)] p-1">
                            {(Object.entries(LANGUAGE_LABELS) as Array<[Locale, string]>).map(([optionLocale, label]) => {
                                const isActive = optionLocale === currentLocale
                                return (
                                    <button
                                        key={optionLocale}
                                        type="button"
                                        onClick={() => requestLanguageSwitch(optionLocale)}
                                        data-active={isActive}
                                        className="glass-selection-control flex w-full items-center justify-between rounded-lg px-3 py-1.5 text-left text-[13px]"
                                    >
                                        <span>{label}</span>
                                        {isActive ? <AppIcon name="check" className="h-3.5 w-3.5 text-[var(--glass-accent-from)]" /> : null}
                                    </button>
                                )
                            })}
                        </div>
                    ) : null}
                </div>
                {confirmDialog}
            </>
        )
    }

    return (
        <>
            <div ref={containerRef} className="relative inline-block">
                <button
                    type="button"
                    onClick={() => setIsMenuOpen((prev) => !prev)}
                    aria-label={SWITCH_CONFIRM_COPY[currentLocale].triggerLabel}
                    aria-expanded={isMenuOpen}
                    className="glass-selection-control inline-flex items-center gap-2 rounded-full px-2.5 py-1.5 text-sm font-medium"
                >
                    <AppIcon name="globe" className="h-4 w-4" />
                    <span>{LANGUAGE_LABELS[currentLocale]}</span>
                    <AppIcon name="chevronDown" className="h-4 w-4 text-[var(--glass-text-tertiary)]" />
                </button>

                {isMenuOpen ? (
                    <div className="glass-surface-modal absolute right-0 z-50 mt-2 w-44 rounded-xl p-2">
                        {(Object.entries(LANGUAGE_LABELS) as Array<[Locale, string]>).map(([locale, label]) => {
                            const isActive = locale === currentLocale
                            return (
                                <button
                                    key={locale}
                                    type="button"
                                    onClick={() => requestLanguageSwitch(locale)}
                                    data-active={isActive}
                                    className="glass-selection-control w-full rounded-lg px-3 py-2 text-left text-sm"
                                >
                                    {label}
                                </button>
                            )
                        })}
                    </div>
                ) : null}
            </div>
            {confirmDialog}
        </>
    )
}
