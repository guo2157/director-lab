import NextAuth from "next-auth"
import { NextRequest, NextResponse } from "next/server"
import { createAuthOptions } from "@/lib/auth"
import { checkRateLimit, getClientIp, AUTH_LOGIN_LIMIT } from '@/lib/rate-limit'
import { logAuthAction } from '@/lib/logging/semantic'
import { editionAuth } from '@/lib/edition/current/auth'

type NextAuthRouteContext = { params: Promise<{ nextauth: string[] }> }
type NextAuthRouteHandler = (req: NextRequest, ctx: NextAuthRouteContext) => Promise<Response>

function createNextAuthHandler(): NextAuthRouteHandler {
    return NextAuth(createAuthOptions()) as unknown as NextAuthRouteHandler
}

/**
 * 登录 POST 请求加 IP 限流保护。
 * 仅对 credentials 与 phone callback（即实际认证行为）做限流，
 * 其他 NextAuth 内部路由（session / csrf 等）不限制。
 *
 * ⚠️ NextAuth 客户端 signIn() 期望响应体包含 { url } 字段，
 *    如果返回自定义 JSON 格式会导致 signIn() 内部 new URL(data.url) 抛异常。
 *    因此限流时返回 NextAuth 兼容的格式：{ url: "...?error=RateLimited" }
 */
async function handlePost(req: NextRequest, ctx: NextAuthRouteContext) {
    const { nextauth: segments } = await ctx.params
    const credentialsProvider =
        segments.length >= 2
        && segments[0] === 'callback'
        && editionAuth.rateLimitedCredentialProviderIds.includes(segments[1])

    if (credentialsProvider) {
        const ip = getClientIp(req)
        const provider = segments[1]
        const rateResult = await checkRateLimit(`auth:${provider}:verify`, ip, AUTH_LOGIN_LIMIT)
        if (rateResult.limited) {
            logAuthAction('LOGIN', 'Login rate limited', { success: false, provider, ip })
            // 返回 NextAuth 兼容的错误格式，signIn() 会解析 URL 中的 error 参数
            const origin = req.nextUrl.origin
            return NextResponse.json(
                { url: `${origin}/auth/signin?error=RateLimited` },
                {
                    status: 429,
                    headers: { 'Retry-After': String(rateResult.retryAfterSeconds) },
                },
            )
        }
    }

    return createNextAuthHandler()(req, ctx)
}

function handleGet(req: NextRequest, ctx: NextAuthRouteContext) {
    return createNextAuthHandler()(req, ctx)
}

export { handleGet as GET, handlePost as POST }
