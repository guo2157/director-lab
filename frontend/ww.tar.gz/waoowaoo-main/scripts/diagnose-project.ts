/**
 * 诊断项目任务状态
 * 运行: npx tsx --env-file=.env scripts/diagnose-project.ts <projectId>
 */
import { prisma } from '../src/lib/prisma'
import { resolveRedisRuntimeConfig } from '../src/lib/redis-config'
import { parseFailureRecord } from '../src/lib/errors/failure'

async function diagnoseProject(projectId: string) {
  console.log(`🔍 诊断项目: ${projectId}\n`)

  // 1. 检查项目是否存在
  console.log('1️⃣ 项目基本信息:')
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: {
      locations: {
        include: {
          images: {
            orderBy: { imageIndex: 'asc' },
          },
        },
      },
    }
  })
  
  if (!project) {
    console.log('  ❌ 项目不存在')
    process.exit(1)
  }
  
  console.log(`  名称: ${project.name}`)
  console.log(`  用户ID: ${project.userId}`)
  console.log(`  视频比例: ${project.videoRatio || '未设置'}`)
  console.log(`  画风提示: ${project.artStylePrompt || '未设置'}`)

  // 2. 检查场景和场景图片
  console.log('\n2️⃣ 场景资产:')
  const locations = project.locations
  
  console.log(`  场景数量: ${locations.length}`)
  
  for (const loc of locations) {
    console.log(`\n  📍 ${loc.name} (${loc.id})`)
    console.log(`     图片数量: ${loc.images?.length || 0}`)
    
    for (const img of loc.images || []) {
      console.log(`     - [${img.imageIndex}] imageUrl: ${img.imageUrl || 'null'}`)
      console.log(`       isSelected: ${img.isSelected}`)
      console.log(`       description: ${img.description || 'null'}`)

      // 检查 MediaObject
      if (img.imageUrl) {
        const media = await prisma.mediaObject.findFirst({
          where: { 
            OR: [
              { storageKey: img.imageUrl },
              { storageKey: { contains: img.imageUrl.split('/').pop() || '' } }
            ]
          }
        })
        if (media) {
          console.log(`       ✅ MediaObject: ${media.publicId}`)
        } else {
          console.log(`       ⚠️ 未找到 MediaObject`)
        }
      }
    }
  }

  // 3. 检查最近的任务
  console.log('\n3️⃣ 最近的任务:')
  const tasks = await prisma.task.findMany({
    where: { projectId },
    orderBy: { createdAt: 'desc' },
    take: 10
  })
  
  console.log(`  任务数量: ${tasks.length}`)
  
  for (const task of tasks) {
    console.log(`\n  📝 ${task.type} (${task.id})`)
    console.log(`     状态: ${task.status}`)
    console.log(`     目标: ${task.targetType} / ${task.targetId}`)
    console.log(`     创建时间: ${task.createdAt}`)
    console.log(`     更新时间: ${task.updatedAt}`)

    const failure = parseFailureRecord(task.failure)
    if (failure) {
      console.log(`     ❌ 错误码: ${failure.interpretation.code}`)
      console.log(`     ❌ 原始错误: ${failure.native.message.substring(0, 200)}`)
      console.log(`     ❌ 错误来源: ${failure.context.system}`)
    }

    // 获取任务事件
    const events = await prisma.taskEvent.findMany({
      where: { taskId: task.id },
      orderBy: { createdAt: 'desc' },
      take: 3
    })
    
    if (events.length > 0) {
      console.log(`     最近事件:`)
      for (const event of events) {
        console.log(`       - ${event.eventType}: ${JSON.stringify(event.payload).substring(0, 100)}`)
      }
    }
  }

  // 5. 检查 Worker 队列状态
  console.log('\n5️⃣ 检查 Worker 配置:')
  console.log(`  REDIS_HOST: ${process.env.REDIS_HOST || '未设置'}`)
  console.log(`  REDIS_PORT: ${process.env.REDIS_PORT || '未设置'}`)
  
  // 尝试连接 Redis
  try {
    const { Redis } = await import('ioredis')
    const redisConfig = resolveRedisRuntimeConfig()
    const redis = new Redis({
      ...redisConfig,
      maxRetriesPerRequest: 3,
      connectTimeout: 5000
    })
    
    const pingResult = await redis.ping()
    console.log(`  ✅ Redis 连接: ${pingResult}`)
    
    redis.disconnect()
  } catch (error) {
    console.log(`  ❌ Redis 连接失败:`, error)
  }

  // 6. 检查模型配置
  console.log('\n6️⃣ 检查用户模型配置:')
  const userPreference = await prisma.userPreference.findUnique({
    where: { userId: project.userId }
  })

  if (!userPreference) {
    console.log('  ❌ 用户偏好配置不存在')
  } else {
    console.log(`  Assistant 模型: ${userPreference.assistantModel || '未设置'}`)
  }

  console.log('\n✨ 诊断完成!')
  
  await prisma.$disconnect()
}

const projectId = process.argv[2]
if (!projectId) {
  console.log('用法: npx tsx --env-file=.env scripts/diagnose-project.ts <projectId>')
  console.log('示例: npx tsx --env-file=.env scripts/diagnose-project.ts fae709e9-9215-4b3f-9f53-dad871f09896')
  process.exit(1)
}

diagnoseProject(projectId).catch(console.error)
