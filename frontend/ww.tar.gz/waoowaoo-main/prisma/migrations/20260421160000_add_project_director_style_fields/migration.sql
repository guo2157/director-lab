ALTER TABLE `projects`
  ADD COLUMN `directorStylePresetId` VARCHAR(191) NULL,
  ADD COLUMN `directorStyleDoc` LONGTEXT NULL;
